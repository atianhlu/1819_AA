/*******************************************************************************
 * Copyright 2015
 * Ubiquitous Knowledge Processing (UKP) Lab
 * Technische Universität Darmstadt
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU Public License v3.0
 * which accompanies this distribution, and is available at
 * http://www.gnu.org/licenses/gpl-3.0.txt
 ******************************************************************************/
package de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.indicators;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.uima.fit.descriptor.ConfigurationParameter;
import org.apache.uima.jcas.JCas;

import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.utils.AbstractPhraseListFeatureExtractor;
import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.utils.FeatureUtils;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token;
import de.tudarmstadt.ukp.dkpro.tc.api.exception.TextClassificationException;
import de.tudarmstadt.ukp.dkpro.tc.api.features.Feature;
import de.tudarmstadt.ukp.dkpro.tc.api.type.TextClassificationUnit;

/**
 * @author Christian Stab
 */
public class PrecedingConnectives extends AbstractPhraseListFeatureExtractor {

	public static final String FN_RELATIONAL_PHRASE_PREFIX = "PrecedingConnective_";
	
	public static final String PARAM_RELATIONAL_PHRASE_LIST_PATH = "connectivesListPath";
	@ConfigurationParameter(name = PARAM_RELATIONAL_PHRASE_LIST_PATH, mandatory = true)
	private String connectivesListPath;

	
	@Override
	public List<Feature> extract(JCas jcas, TextClassificationUnit classificationUnit) throws TextClassificationException {
	   	List<Feature> featList = new ArrayList<Feature>();
	   	
	   	//Sentence sentence = FeatureUtils.getCoveringSentence(classificationUnit);
	   	
	   	ArrayList<Token> precedingTokens = FeatureUtils.getPrecedingTokens(jcas, classificationUnit);
	   	
	   	HashMap<String, Integer> found = phraseMap.getPhrases(precedingTokens); 
	   	
	   	for (String phrase : phraseMap.getPhrases()) {
	   		if (found.containsKey(phrase)) {
	   			featList.add(new Feature(getFeaturePrefix() + phrase.replace(" ", "_"), true));
	   		} else {
	   			featList.add(new Feature(getFeaturePrefix() + phrase.replace(" ", "_"), false));
	   		}
	   	}
	   	
	   	return featList;
   }
	

	public String getFeaturePrefix() {
		return "PrecedingConnective_";
	}
	
	public String getPhraseListPath() {
		return connectivesListPath;
	}


	
	
}
