/*******************************************************************************
 * Copyright 2015
 * Ubiquitous Knowledge Processing (UKP) Lab
 * Technische Universität Darmstadt
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU Public License v3.0
 * which accompanies this distribution, and is available at
 * http://www.gnu.org/licenses/gpl-3.0.txt
 ******************************************************************************/
package de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.evaluation;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 * @author Christian Stab
 */
public class ConfusionMatrix {

	private String[] headers;
	
	private int size = -1;
	
	private double[][] matrix;
	
	public static void main (String[] args) throws IOException {
		ConfusionMatrix result = new ConfusionMatrix(4);
		result.setHeaders(new String[] {"Claim", "MajorClaim", "None", "Premise"});
		
		File path = new File("src/main/resources/results/matrices");
		
		for (File f : path.listFiles()) {
			ConfusionMatrix m = new ConfusionMatrix(f);
			result.add(m);
		}
		
		result.print();
		System.out.println(result.sum());
		System.out.println();

		result.printEval("MajorClaim");
		result.printEval("Claim");
		result.printEval("Premise");
		result.printEval("None");
		result.printEval();
	}
	
	
	public ConfusionMatrix(int size) {
		this.size = size;
		matrix = new double[size][size];
	}
	
	public ConfusionMatrix(File f) throws IOException {
		FileReader in = new FileReader(f);
		BufferedReader br = new BufferedReader(in);
		String line = br.readLine();
		headers = line.split(",");	
		size = headers.length-1;
		matrix = new double[size][size];
		
		int linecounter = 0;
		while ((line=br.readLine())!=null && !line.equals("")) {
			//System.out.println(line);
			String[] split = line.split(",");
			
			for (int i=1; i<size+1;i++) {
				double value = Double.parseDouble(split[i].replace("\"", ""));
				//System.out.println(value);
				matrix[linecounter][i-1] = value;
			}
				
			linecounter++;
		}
		br.close();
	}
	
	
	public void print() {
		for (int i=0; i<size; i++) {
			for (int j=0; j<size; j++) {
				System.out.print(matrix[i][j] + "\t");
			}
			System.out.println();
		}
	}
	
	
	public void add(ConfusionMatrix m) {
		for (int i=0; i<size; i++) {
			for (int j=0; j<size; j++) {
				matrix[i][j] += m.getValue(i, j); 
			}
		}
	}

	
	public double sum() {
		double sum = 0.0;
		for (int i=0; i<size; i++) {
			for (int j=0; j<size; j++) {
				sum += matrix[i][j]; 
			}
		}
		return sum;
	}
	
	public String[] getHeaders() {
		return headers;
	}
	
	public void setHeaders(String[] headers) {
		this.headers = headers;
	}
	
	public int getIndexOf(String category) {
		for (int i=0; i<headers.length; i++) {
			if (headers[i].equals(category)) return i;
		}
		return -1;
	}
	
	public double getValue(int i, int j) {
		return matrix[i][j];
	}
	
	public double TP(String category) {
		int catIndex=getIndexOf(category);
		return matrix[catIndex][catIndex];
	}
	
	public double TP() {
		double tp = 0.0;
		for (int i=0; i<size; i++) {
			tp = tp + matrix[i][i];
		}
		
		return tp;
	}
	
	public double FP(String category) {
		int catIndex=getIndexOf(category);
		double fp = 0.0; 
		for (int i=0; i<size; i++) {
			if (i!=catIndex) fp = fp + matrix[i][catIndex];
		}
		return fp;
	}
	
	public double FP() {
		double fp = 0.0; 
		for (String s : headers) {
			fp = fp + FP(s);
		}
		return fp;
	}
	
	public double FN(String category) {
		int catIndex=getIndexOf(category);
		double fn = 0.0; 
		for (int i=0; i<size; i++) {
			if (i!=catIndex) fn = fn + matrix[catIndex][i];
		}
		
		return fn;
	}
	
	public double FN() {
		double fn = 0.0; 
		for (String s : headers) {
			fn = fn + FN(s);
		}
		return fn;
	}
	
	public double TN() {
		double tn = 0.0; 
		for (int i=0; i<size; i++) {
			for (int j=0; j<size; j++) {
				tn = tn + matrix[i][j];
			}
		}
		
		return tn;
	}
	
	public double F(String category) {
		//double tp, fp, fn = 0.0;
		double tp = TP(category);
		double fp = FP(category);
		double fn = FN(category);
		return (2*tp)/(2*tp+fp+fn);
	}
	
	public double F() {
		double tp, fp, fn = 0.0;
		tp = TP();
		fp = FP();
		fn = FN();
		return (2*tp)/(2*tp+fp+fn);
	}
	
	public double P(String category) {
		return TP(category) / (TP(category) + FP(category));
	}
	
	public double P() {
		return TP() / (TP() + FP());
	}
	
	public double Pmacro() {
		double psum = 0.0;
		for (String s : headers) {
			psum = psum + P(s);
		}
		return psum/headers.length;
	}
	
	public double Rmacro() {
		double rsum = 0.0;
		for (String s : headers) {
			rsum = rsum + R(s);
		}
		return rsum/headers.length;
	}
	
	public double Fmacro() {
		double rmacro = Rmacro();
		double pmacro = Pmacro();
		return 2.0*(rmacro*pmacro)/(rmacro+pmacro);
	}
	
	public double R(String category) {
		return TP(category) / (TP(category) + FN(category));
	}
	
	public double R() {
		return TP() / (TP() + FN());
	}
	
	public void printEval(String category) {
		System.out.println("Category: " + category);
		System.out.println("  F         = " + F(category));
		System.out.println("  precision = " + P(category));
		System.out.println("  recall    = " + R(category));
		System.out.println("  TP        = " + TP(category));
		System.out.println("  FP        = " + FP(category));
		System.out.println("  FN        = " + FN(category));
		System.out.println();
	}
	
	public void printEval() {
		System.out.println("Overall Results (micro-avg)");
		System.out.println("  F         = " + F());
		System.out.println("  acc       = " + TP() / sum());
		System.out.println();
		System.out.println("Overall Results (macro-avg)");
		System.out.println("  acc       = " + TP() / sum());
		System.out.println("  F[macro]  = " + Fmacro());
		System.out.println("  P[macro]  = " + Pmacro());
		System.out.println("  R[macro]  = " + Rmacro());
		
	}
	
}
