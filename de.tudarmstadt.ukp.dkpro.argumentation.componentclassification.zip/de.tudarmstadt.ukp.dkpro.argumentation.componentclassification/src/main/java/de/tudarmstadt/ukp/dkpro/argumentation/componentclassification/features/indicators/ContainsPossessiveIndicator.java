/*******************************************************************************
 * Copyright 2015
 * Ubiquitous Knowledge Processing (UKP) Lab
 * Technische Universität Darmstadt
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU Public License v3.0
 * which accompanies this distribution, and is available at
 * http://www.gnu.org/licenses/gpl-3.0.txt
 ******************************************************************************/
package de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.indicators;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.uima.fit.descriptor.ConfigurationParameter;
import org.apache.uima.fit.util.JCasUtil;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceInitializationException;
import org.apache.uima.resource.ResourceSpecifier;
import org.apache.uima.util.Level;

import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.utils.FeatureUtils;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Sentence;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token;
import de.tudarmstadt.ukp.dkpro.tc.api.exception.TextClassificationException;
import de.tudarmstadt.ukp.dkpro.tc.api.features.ClassificationUnitFeatureExtractor;
import de.tudarmstadt.ukp.dkpro.tc.api.features.Feature;
import de.tudarmstadt.ukp.dkpro.tc.api.features.FeatureExtractorResource_ImplBase;
import de.tudarmstadt.ukp.dkpro.tc.api.type.TextClassificationUnit;

/**
 * @author Christian Stab
 */
public class ContainsPossessiveIndicator extends FeatureExtractorResource_ImplBase implements ClassificationUnitFeatureExtractor {
	
	public static final String FN_CONTAINS_POSSESSIVE_INDICATOR = "Contains_Possessive_Indicator";
	
	public static final String PARAM_POSSESSIVE_INDICATOR_LIST_PATH = "possessiveWordListPath";
    @ConfigurationParameter(name = PARAM_POSSESSIVE_INDICATOR_LIST_PATH, mandatory = true)
    private String possessiveWordListPath;
	
    private Set<String> possessives;
    
    @Override
    public boolean initialize(ResourceSpecifier aSpecifier, Map<String, Object> aAdditionalParams) throws ResourceInitializationException {
        super.initialize(aSpecifier, aAdditionalParams);
        possessives = new HashSet<String>();       
        try {
        	BufferedReader br = new BufferedReader(new FileReader(new File(possessiveWordListPath)));
        	getLogger().log(Level.INFO, "Loading possessive words from " + possessiveWordListPath);
            String line;          
			while((line = br.readLine()) != null) {
				possessives.add(line.toLowerCase());
			}            
            br.close();
        }        
        catch (IOException e) {
            throw new ResourceInitializationException(e);
        }
        return true;
    }
	
 
    public List<Feature> extract(JCas jcas, TextClassificationUnit classificationUnit) throws TextClassificationException {
    	List<Feature> featList = new ArrayList<Feature>();
    	
    	boolean indicatorFound = false;
    	Sentence sentence = FeatureUtils.getCoveringSentence(classificationUnit);
    	Collection<Token> tokens = JCasUtil.selectCovered(jcas, Token.class, sentence);
    	
    	for (Token t : tokens) {
    		if (possessives.contains(t.getCoveredText().toLowerCase())) indicatorFound = true;
    	}

    	featList.add(new Feature(FN_CONTAINS_POSSESSIVE_INDICATOR, indicatorFound));
    	return featList;
    }
}
