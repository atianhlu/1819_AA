/*******************************************************************************
 * Copyright 2015
 * Ubiquitous Knowledge Processing (UKP) Lab
 * Technische Universität Darmstadt
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU Public License v3.0
 * which accompanies this distribution, and is available at
 * http://www.gnu.org/licenses/gpl-3.0.txt
 ******************************************************************************/
package de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.utils;

import java.io.File;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.apache.uima.UimaContext;
import org.apache.uima.analysis_engine.AnalysisEngineProcessException;
import org.apache.uima.fit.descriptor.ConfigurationParameter;
import org.apache.uima.fit.util.JCasUtil;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceInitializationException;

import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.lexical.VerbsInClause;
import de.tudarmstadt.ukp.dkpro.core.api.frequency.util.FrequencyDistribution;
import de.tudarmstadt.ukp.dkpro.core.api.lexmorph.type.pos.V;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token;
import de.tudarmstadt.ukp.dkpro.tc.api.type.TextClassificationUnit;
import de.tudarmstadt.ukp.dkpro.tc.features.ngram.meta.FreqDistBasedMetaCollector;

/**
 * @author Christian Stab
 */
public class VerbMetaCollector extends FreqDistBasedMetaCollector{

	public static final String VERB_FD_KEY = "verbs.ser";
    @ConfigurationParameter(name = VerbsInClause.PARAM_VERB_FD_FILE, mandatory = true)
    private File verbFdFile;
    
    @Override
    public void initialize(UimaContext context) throws ResourceInitializationException {
        super.initialize(context);

    }
    
    
    @Override
    public void process(JCas jcas) throws AnalysisEngineProcessException {
    	
        FrequencyDistribution<String> verbs = new FrequencyDistribution<String>();
        
        Collection<TextClassificationUnit> units = JCasUtil.select(jcas, TextClassificationUnit.class);
        for (TextClassificationUnit u : units) {
        	Collection<Token> tokens = JCasUtil.selectCovered(Token.class, u);
        	for (Token t : tokens) {
        		if (t.getPos() instanceof V) {
        			verbs.addSample(t.getLemma().getValue(), 1);
        		}
        	}
        }
     

        for (String ngram : verbs.getKeys()) {
            fd.addSample(ngram, verbs.getCount(ngram));
        }
    }

    @Override
    public Map<String, String> getParameterKeyPairs() {
        Map<String, String> mapping = new HashMap<String, String>();
        mapping.put(VerbsInClause.PARAM_VERB_FD_FILE, VERB_FD_KEY);
        return mapping;
    }

    @Override
    protected File getFreqDistFile() {
        return verbFdFile;
    }
}
