/*******************************************************************************
 * Copyright 2015
 * Ubiquitous Knowledge Processing (UKP) Lab
 * Technische Universität Darmstadt
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU Public License v3.0
 * which accompanies this distribution, and is available at
 * http://www.gnu.org/licenses/gpl-3.0.txt
 ******************************************************************************/
package de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.utils;

import static org.apache.uima.fit.factory.AnalysisEngineFactory.createEngineDescription;
import static org.apache.uima.fit.pipeline.SimplePipeline.runPipeline;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import org.apache.uima.UIMAException;
import org.apache.uima.analysis_engine.AnalysisEngineDescription;
import org.apache.uima.fit.factory.JCasFactory;
import org.apache.uima.fit.util.JCasUtil;
import org.apache.uima.jcas.JCas;

import de.tudarmstadt.ukp.dkpro.core.api.metadata.type.DocumentMetaData;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token;
import de.tudarmstadt.ukp.dkpro.core.languagetool.LanguageToolSegmenter;

/**
 * @author Christian Stab
 */
public class PhraseMap {

	private Set<String> phrases;
	
	public PhraseMap(String path) {
		phrases = new HashSet<String>();
       
        try {
        	BufferedReader br = new BufferedReader(new FileReader(new File(path)));
            String line;          
			while((line = br.readLine()) != null) {
				phrases.add(line);
			}            
            br.close();
        } catch (IOException e) {
        	e.printStackTrace();
        }        
	}
	
	
	public HashMap<String,Integer> getPhrases(Collection<Token> tokens) {
		HashMap<String, Integer> result = new HashMap<String,Integer>();
		int position = -1;
		for (String con : phrases) {
			if ((position = containsTokenSequence(tokens, con))>-1) {
				result.put(con, position);
			}
			
		}
		return result;
	}
	
	
	public Set<String> getPhrases() {
		return phrases;
	}
	
	
	public static boolean startsWithUpperCase(Collection<Token> tokens, int index) {
		Token t = (Token)tokens.toArray()[index];
		return Character.isUpperCase(t.getCoveredText().charAt(0));
	}
	
	
	private int containsTokenSequence(Collection<Token> tokens, String sequence) {
		String[] split = sequence.toLowerCase().split(" ");
		int position = 0;
		int conIndex = 0;
		int sequenceIndex = 0;
		for (Token t : tokens) {
			if (t.getCoveredText().toLowerCase().equals(split[sequenceIndex])) {
				if (sequenceIndex==0) conIndex = position;
				sequenceIndex++;
			}
			else sequenceIndex = 0; 
			if (sequenceIndex==split.length) {
				return conIndex;
			}
			position++;
		}
		
		return -1;
	}
	
	
	public static void main(String[] args) throws UIMAException {
		JCas jcas = JCasFactory.createJCas();
		// jcas.setDocumentText("neither the one nor the other");
		jcas.setDocumentText("On the one hand this is like that and On the other hand bla bla blub");
		DocumentMetaData meta = DocumentMetaData.create(jcas);
		meta.setLanguage("en");
		
		AnalysisEngineDescription segmenter = createEngineDescription(LanguageToolSegmenter.class);
		runPipeline(jcas, segmenter);
		
		PhraseMap map = new PhraseMap("src/main/resources/indicators/connectives.txt");
		HashMap<String, Integer> test = map.getPhrases(JCasUtil.select(jcas, Token.class));
		
		for (String c : test.keySet()) {
			System.out.println("Found Connective: " + c + "  position=" + test.get(c) + "  upperCase=" + PhraseMap.startsWithUpperCase(JCasUtil.select(jcas, Token.class), test.get(c)));
		}
	}
	
}
