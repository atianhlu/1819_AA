/*******************************************************************************
 * Copyright 2015
 * Ubiquitous Knowledge Processing (UKP) Lab
 * Technische Universität Darmstadt
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU Public License v3.0
 * which accompanies this distribution, and is available at
 * http://www.gnu.org/licenses/gpl-3.0.txt
 ******************************************************************************/
package de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.experiments;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.uima.analysis_engine.AnalysisEngineDescription;
import org.apache.uima.fit.factory.AnalysisEngineFactory;
import org.apache.uima.resource.ResourceInitializationException;

import weka.attributeSelection.InfoGainAttributeEval;
import weka.attributeSelection.Ranker;
import weka.classifiers.functions.SMO;
import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.context.ModalVerbsInContext;
import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.context.NrOfPunctuationsInContext;
import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.context.NrOfSubclausesInContext;
import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.context.NrOfTokensInContext;
import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.indicators.ContainsPossessiveIndicator;
import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.indicators.NrOfPossessiveIndicators;
import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.indicators.PrecedingConnectives;
import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.indicators.PrecedingPossessives;
import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.lexical.AdverbsInClause;
import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.lexical.ContainsModalVerb;
import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.lexical.NGrams;
import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.lexical.VerbsInClause;
import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.structural.ContainsQuestionMark;
import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.structural.NrOfParagraphSentences;
import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.structural.NrOfPunctuations;
import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.structural.NrOfTokens;
import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.structural.PositionInParagraph;
import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.structural.PositionInSentence;
import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.structural.PresentInIntroductionConclusion;
import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.syntactic.DependencyTreeDepth;
import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.syntactic.NrOfSubClauses;
import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.syntactic.PastTenseSentence;
import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.syntactic.ProductionRules;
import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.readers.ArgumentReader;
import de.tudarmstadt.ukp.dkpro.lab.Lab;
import de.tudarmstadt.ukp.dkpro.lab.task.Dimension;
import de.tudarmstadt.ukp.dkpro.lab.task.ParameterSpace;
import de.tudarmstadt.ukp.dkpro.lab.task.impl.BatchTask.ExecutionPolicy;
import de.tudarmstadt.ukp.dkpro.tc.core.Constants;
import de.tudarmstadt.ukp.dkpro.tc.weka.report.BatchTrainTestReport;
import de.tudarmstadt.ukp.dkpro.tc.weka.task.BatchTaskTrainTest;
import de.tudarmstadt.ukp.dkpro.tc.weka.writer.WekaDataWriter;

/**
 * @author Christian Stab
 */
public class ComponentClassification implements Constants {
	
	public static final String RESULT_PATH 		= "src/main/resources/results";
	public static final String LANGUAGE_CODE 	= "en";

    public static final String FILEPATH_TRAIN 	= "src/main/resources/data/train";
    public static final String FILEPATH_TEST 	= "src/main/resources/data/test";

    
    public static void main(String[] args) throws Exception {
    	System.setProperty("DKPRO_HOME", RESULT_PATH);
    	ComponentClassification demo = new ComponentClassification();
        demo.runTrainTest(getParameterSpace());
    }

    
    protected void runTrainTest(ParameterSpace pSpace) throws Exception {
        BatchTaskTrainTest batch = new BatchTaskTrainTest("ArgCompClassification-TT", getPreprocessing());
        batch.setParameterSpace(pSpace);
        batch.setExecutionPolicy(ExecutionPolicy.RUN_AGAIN);
        batch.addReport(BatchTrainTestReport.class);

        // Run
        Lab.getInstance().run(batch);
    }

    
    public static ParameterSpace getParameterSpace() {
        Map<String, Object> dimReaders = new HashMap<String, Object>();
        dimReaders.put(DIM_READER_TRAIN, ArgumentReader.class);
        dimReaders.put(DIM_READER_TRAIN_PARAMS, Arrays.asList(new Object[] {
        	ArgumentReader.PARAM_SOURCE_LOCATION, FILEPATH_TRAIN,
        	ArgumentReader.PARAM_LANGUAGE, LANGUAGE_CODE,			
 			ArgumentReader.PARAM_PATTERNS, ArgumentReader.INCLUDE_PREFIX + "*.xmi"
        }));
        dimReaders.put(DIM_READER_TEST, ArgumentReader.class);
        dimReaders.put(DIM_READER_TEST_PARAMS, Arrays.asList(new Object[] {
        	ArgumentReader.PARAM_SOURCE_LOCATION, FILEPATH_TEST,
        	ArgumentReader.PARAM_LANGUAGE, LANGUAGE_CODE,			
 			ArgumentReader.PARAM_PATTERNS, ArgumentReader.INCLUDE_PREFIX + "*.xmi"
        }));

        @SuppressWarnings("unchecked")
        Dimension<List<String>> dimClassificationArgs = Dimension.create(DIM_CLASSIFICATION_ARGS, Arrays.asList(new String[] { SMO.class.getName() }));

        @SuppressWarnings("unchecked")
        Dimension<List<String>> dimFeatureSets = Dimension.create(DIM_FEATURE_SET, Arrays.asList(new String[] {
        		
        	// structural features
    		PresentInIntroductionConclusion.class.getName(), 
    		PositionInParagraph.class.getName(), 			
    		NrOfTokens.class.getName(),						
    		NrOfParagraphSentences.class.getName(),			
    		NrOfPunctuations.class.getName(),				
    		ContainsQuestionMark.class.getName(),
    		PositionInSentence.class.getName(),			
    		
    		// lexical features
    		ContainsModalVerb.class.getName(),
    		VerbsInClause.class.getName(),
    		AdverbsInClause.class.getName(),
    		NGrams.class.getName(),
    		
    		// syntactic features
    		NrOfSubClauses.class.getName(),
    		DependencyTreeDepth.class.getName(),
    		ProductionRules.class.getName(),
    		PastTenseSentence.class.getName(),

    		// indicator features
    		ContainsPossessiveIndicator.class.getName(),
    		NrOfPossessiveIndicators.class.getName(),
    		PrecedingPossessives.class.getName(),
    		PrecedingConnectives.class.getName(),
    		
    		// context features
    		NrOfPunctuationsInContext.class.getName(),
    		NrOfTokensInContext.class.getName(),
    		NrOfSubclausesInContext.class.getName(),
    		ModalVerbsInContext.class.getName()
        }));

        // parameters to configure feature extractors
        @SuppressWarnings("unchecked")
        Dimension<List<Object>> dimPipelineParameters = Dimension.create(DIM_PIPELINE_PARAMS, Arrays.asList(new Object[] {

    		// possessives
    		ContainsPossessiveIndicator.PARAM_POSSESSIVE_INDICATOR_LIST_PATH,	"src/main/resources/indicators/possessives.txt",
    		NrOfPossessiveIndicators.PARAM_POSSESSIVE_INDICATOR_LIST_PATH,      "src/main/resources/indicators/possessives.txt",
    		PrecedingPossessives.PARAM_POSSESSIVE_INDICATOR_LIST_PATH, 			"src/main/resources/indicators/possessives.txt",
    		
    		// connectives
    		PrecedingConnectives.PARAM_RELATIONAL_PHRASE_LIST_PATH, 			"src/main/resources/indicators/connectives.txt",
    		
    		NGrams.PARAM_NGRAM_MAX_N, 1,
    		NGrams.PARAM_NGRAM_MAX_N, 3,
    		NGrams.PARAM_NGRAM_USE_TOP_K, 999999999,
    		NGrams.PARAM_NGRAM_FREQ_THRESHOLD, 5
        }));
     
        // feature selection
        Map<String, Object> dimFeatureSelection = new HashMap<String, Object>();
        dimFeatureSelection.put(DIM_FEATURE_SEARCHER_ARGS, Arrays.asList(new String[] { Ranker.class.getName(), "-N", "100" }));
        dimFeatureSelection.put(DIM_ATTRIBUTE_EVALUATOR_ARGS, Arrays.asList(new String[] { InfoGainAttributeEval.class.getName() }));
        dimFeatureSelection.put(DIM_APPLY_FEATURE_SELECTION, true);
        
        @SuppressWarnings("unchecked")
        ParameterSpace pSpace = new ParameterSpace(
        	Dimension.createBundle("readers", dimReaders), 
        	Dimension.create(DIM_DATA_WRITER, WekaDataWriter.class.getName()), 
        	Dimension.create(DIM_LEARNING_MODE, LM_SINGLE_LABEL), 
        	Dimension.create(DIM_FEATURE_MODE, FM_UNIT), 
        	dimPipelineParameters,
            dimFeatureSets, 
            dimClassificationArgs,
            Dimension.createBundle("featureSelection",dimFeatureSelection)
        );
        return pSpace;
    }

    
    protected AnalysisEngineDescription getPreprocessing() throws ResourceInitializationException {
        return AnalysisEngineFactory.createEngineDescription();
    }

}
