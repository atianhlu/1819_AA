/*******************************************************************************
 * Copyright 2015
 * Ubiquitous Knowledge Processing (UKP) Lab
 * Technische Universität Darmstadt
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU Public License v3.0
 * which accompanies this distribution, and is available at
 * http://www.gnu.org/licenses/gpl-3.0.txt
 ******************************************************************************/
package de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.syntactic;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.uima.fit.util.JCasUtil;
import org.apache.uima.jcas.JCas;

import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.utils.FeatureUtils;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Sentence;
import de.tudarmstadt.ukp.dkpro.core.api.syntax.type.constituent.ROOT;
import de.tudarmstadt.ukp.dkpro.core.stanfordnlp.util.TreeUtils;
import de.tudarmstadt.ukp.dkpro.tc.api.exception.TextClassificationException;
import de.tudarmstadt.ukp.dkpro.tc.api.features.ClassificationUnitFeatureExtractor;
import de.tudarmstadt.ukp.dkpro.tc.api.features.Feature;
import de.tudarmstadt.ukp.dkpro.tc.api.features.FeatureExtractorResource_ImplBase;
import de.tudarmstadt.ukp.dkpro.tc.api.type.TextClassificationUnit;
import edu.stanford.nlp.trees.Tree;

/**
 * @author Christian Stab
 */
public class DependencyTreeDepth extends FeatureExtractorResource_ImplBase implements ClassificationUnitFeatureExtractor {

    public static final String FN_DEPENDENCY_TREE_DEPTH = "DependencyTreeDepth";

    public List<Feature> extract(JCas jcas, TextClassificationUnit classificationUnit) throws TextClassificationException {
        List<Feature> featList = new ArrayList<Feature>();
        
        Sentence sentence = FeatureUtils.getCoveringSentence(classificationUnit);
        
        Collection<ROOT> root =	JCasUtil.selectCovered(ROOT.class,sentence);
		if (!root.isEmpty()) {
			Tree tree = TreeUtils.createStanfordTree(root.iterator().next());
			featList.add(new Feature(FN_DEPENDENCY_TREE_DEPTH, tree.depth()));
		} else {
			featList.add(new Feature(FN_DEPENDENCY_TREE_DEPTH, 0.0));
		}
       
        return featList;
    }

}
