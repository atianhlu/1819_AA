/*******************************************************************************
 * Copyright 2015
 * Ubiquitous Knowledge Processing (UKP) Lab
 * Technische Universität Darmstadt
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU Public License v3.0
 * which accompanies this distribution, and is available at
 * http://www.gnu.org/licenses/gpl-3.0.txt
 ******************************************************************************/
package de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.syntactic;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.uima.fit.util.JCasUtil;
import org.apache.uima.jcas.JCas;

import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.utils.FeatureUtils;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Sentence;
import de.tudarmstadt.ukp.dkpro.core.api.syntax.type.constituent.ROOT;
import de.tudarmstadt.ukp.dkpro.core.stanfordnlp.util.TreeUtils;
import de.tudarmstadt.ukp.dkpro.tc.api.exception.TextClassificationException;
import de.tudarmstadt.ukp.dkpro.tc.api.features.ClassificationUnitFeatureExtractor;
import de.tudarmstadt.ukp.dkpro.tc.api.features.Feature;
import de.tudarmstadt.ukp.dkpro.tc.api.features.FeatureExtractorResource_ImplBase;
import de.tudarmstadt.ukp.dkpro.tc.api.type.TextClassificationUnit;
import edu.stanford.nlp.trees.Tree;

/**
 * @author Christian Stab
 */
public class PastTenseSentence extends FeatureExtractorResource_ImplBase implements ClassificationUnitFeatureExtractor {

	
	public static final String FN_PAST_TENSE_SENTENCE = "PastTenseSentence";
	
	
    public List<Feature> extract(JCas jcas, TextClassificationUnit classificationUnit) throws TextClassificationException {
    	List<Feature> featList = new ArrayList<Feature>();
    	
    	boolean pastTenseVerbPresent = false;
    	//Collection<Token> tokens = JCasUtil.selectCovered(jcas, Token.class, classificationUnit);
    	
    	Sentence sentence = FeatureUtils.getCoveringSentence(classificationUnit);
    	
    	String mainVerbPos = null;
    	Collection<ROOT> root =	JCasUtil.selectCovered(ROOT.class,sentence);
    	if (!root.isEmpty()) {
			Tree tree = TreeUtils.createStanfordTree(root.iterator().next());
			mainVerbPos = getMainVerbPos(tree.iterator().next());
		}
    	if (mainVerbPos!=null && (mainVerbPos.equals("VBD") || mainVerbPos.equals("VBN"))) pastTenseVerbPresent = true;

    	featList.add(new Feature(FN_PAST_TENSE_SENTENCE, pastTenseVerbPresent));
    	return featList;
    }
	
	public String getMainVerbPos(Tree tree) {
		
		if (tree.getChildrenAsList().size()>0) {
			for (Tree subTree : tree.getChildrenAsList()) {
				if (subTree.value().equals("VP")) {
					Tree verbTree = subTree.getChildrenAsList().iterator().next();
					return verbTree.value();
				}
			}
		}
		
		for (Tree t : tree.getChildrenAsList()) {
			String subtreeResult = getMainVerbPos(t); 
			if (subtreeResult!=null) return subtreeResult;
		}
		
		return null;
	}
}
