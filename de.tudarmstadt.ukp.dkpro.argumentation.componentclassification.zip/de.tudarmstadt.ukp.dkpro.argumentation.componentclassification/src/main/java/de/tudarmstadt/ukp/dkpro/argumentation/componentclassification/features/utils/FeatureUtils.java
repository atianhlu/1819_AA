/*******************************************************************************
 * Copyright 2015
 * Ubiquitous Knowledge Processing (UKP) Lab
 * Technische Universität Darmstadt
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU Public License v3.0
 * which accompanies this distribution, and is available at
 * http://www.gnu.org/licenses/gpl-3.0.txt
 ******************************************************************************/
package de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import org.apache.uima.fit.util.JCasUtil;
import org.apache.uima.jcas.JCas;
import org.apache.uima.jcas.tcas.Annotation;

import de.tudarmstadt.ukp.dkpro.argumentation.types.ArgumentComponent;
import de.tudarmstadt.ukp.dkpro.core.api.lexmorph.type.pos.PUNC;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Paragraph;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Sentence;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token;

/**
 * @author Christian Stab
 */
public class FeatureUtils {

	public static Sentence getSentenceBefore(JCas jcas, Sentence sentence, boolean considerParagraphBoundaries) {
		Collection<Sentence> sentences = JCasUtil.select(jcas, Sentence.class);
		Sentence before = null;
		for (Sentence s : sentences) {
			if (s.getBegin()==sentence.getBegin() && s.getEnd()==sentence.getEnd()) break;
			before = s;
		}
		
		if (considerParagraphBoundaries) {
			return (isInSameParagraph(jcas, sentence, before))?before:null;
		} else {
			return before;
		}
	}
	
	
	public static Sentence getSentenceNext(JCas jcas, Sentence sentence, boolean considerParagraphBoundaries) {
		Collection<Sentence> sentences = JCasUtil.select(jcas, Sentence.class);
		boolean foundSentence = false;
		Sentence next = null;
		for (Sentence s : sentences) {
			if (foundSentence) {
				next = s;
				break;
			}
			if (s.getBegin()==sentence.getBegin() && s.getEnd()==sentence.getEnd()) {
				foundSentence = true;
			}
		}
		if (considerParagraphBoundaries) {
			return (isInSameParagraph(jcas, sentence, next))?next:null;
		} else {
			return next;
		}
	}

	
	public static boolean isInSameParagraph(JCas jcas, Sentence s1, Sentence s2) {
		return s1!=null && s2!=null && getCoveringParpagraph(s1)==getCoveringParpagraph(s2);
	}
	
	
	public static Paragraph getCoveringParpagraph(Sentence sentence) {
		Collection<Paragraph> paragraphs = JCasUtil.selectCovering(Paragraph.class, sentence);
		if(paragraphs.size() != 1) {
    		return null;
    	} else {
    		return paragraphs.iterator().next();
    	}
	}
	
	
	public static Sentence[] getPreviousSentences(JCas jcas, int n, Sentence sentence, boolean considerParagraphBoundaries) {
		ArrayList<Sentence> sentences = getSentenceArrayList(JCasUtil.select(jcas, Sentence.class));
		int sentenceIndex = getSentenceIndex(sentences, sentence);
		Sentence[] result = new Sentence[n];
		
		for (int i=0; i<n; i++) {
			if (sentenceIndex-n+i>0 && sentenceIndex-n+i<sentences.size()) {
				if (considerParagraphBoundaries) {
					if (isInSameParagraph(jcas, sentence,sentences.get(sentenceIndex-n+i))) {
						result[i] = sentences.get(sentenceIndex-n+i);
					}
				} else {
					result[i] = sentences.get(sentenceIndex-n+i);
				}
			}
		}
		
		return result;
	}
	
	
	public static Sentence[] getNextSentences(JCas jcas, int n, Sentence sentence, boolean considerParagraphBoundaries) {
		ArrayList<Sentence> sentences = getSentenceArrayList(JCasUtil.select(jcas, Sentence.class));
		int sentenceIndex = getSentenceIndex(sentences, sentence);
		Sentence[] result = new Sentence[n];
		
		for (int i=0; i<n; i++) {
			if (sentenceIndex+i+1>0 && sentenceIndex+i+1<sentences.size()) {
				if (considerParagraphBoundaries) {
					if (isInSameParagraph(jcas, sentence,sentences.get(sentenceIndex+i+1))) {
						result[i] = sentences.get(sentenceIndex+i+1);
					}
				} else {
					result[i] = sentences.get(sentenceIndex+i+1);
				}
			}
		}
		
		return result;
	}
	
	
	public static ArrayList<Sentence> getSentenceArrayList(Collection<Sentence> collection) {
		ArrayList<Sentence> sentences = new ArrayList<Sentence>();
		
		for (Sentence s : collection) {
			sentences.add(s);
		}
		return sentences;
	}
	
	
	public static ArrayList<Token> getTokenArrayList(Collection<Token> collection) {
		ArrayList<Token> tokens = new ArrayList<Token>();
		
		for (Token s : collection) {
			tokens.add(s);
		}
		return tokens;
	}
	
	
	private static int getSentenceIndex(ArrayList<Sentence> sentences, Sentence s) {
		return sentences.indexOf(s);
	}
	
	public static HashMap<String,Integer> getWordPairs(Collection<Token> arg1, Collection<Token> arg2) {
		HashMap<String, Integer> result = new HashMap<String, Integer>();
		for (Token t : arg1) {
			if (!(t.getPos() instanceof PUNC) ) {
				String arg1Token = t.getLemma().getValue();
				for (Token s : arg2) {
					if (!(s.getPos() instanceof PUNC) ) { 
						String arg2Token = s.getLemma().getValue();
						String pair = arg1Token + "_" + arg2Token; 
						if (result.containsKey(pair)) {
							result.put(pair, result.get(pair) + 1);
						} else {
							result.put(pair, 1);
						}
					}
				}
			}
		}
		return result;
	}
	
	
	public static Sentence getCoveringSentence(Annotation classificationUnit) {
		Collection<Sentence> sentences = JCasUtil.selectCovering(Sentence.class, classificationUnit);
		if (sentences.size()!=1) return null;
		else return sentences.iterator().next();
	}
	
	
	public static int getStartToken(ArrayList<Token> sentenceToken, ArrayList<Token> propTokens) {
		if (propTokens.size()==0) return -1;
		String firstPropWord = propTokens.get(0).getCoveredText();
		for (int i=0; i<sentenceToken.size(); i++) {
			Token t = sentenceToken.get(i);
			if (t.getCoveredText().equals(firstPropWord)) {
				boolean match = true;
				for (int j=0; j<propTokens.size(); j++) {
					if (!sentenceToken.get(i+j).getCoveredText().equals(propTokens.get(j).getCoveredText())) match = false;
				}
				if (match) return i;
			}
		}
		return -1;
	}
	
	
	public static ArrayList<Token> getPrecedingTokens(JCas jcas, Annotation classificationUnit) {
		ArrayList<Token> tokens = new ArrayList<Token>();
		Sentence sentence = getCoveringSentence(classificationUnit);
		
		ArgumentComponent preceding = getPrecedingArgProp(classificationUnit);
		
		if (preceding!=null && preceding.getBegin()>=sentence.getBegin()) {
			Collection<Token> t = JCasUtil.selectBetween(Token.class, preceding, classificationUnit);
			tokens.addAll(t);
		} else {
			ArrayList<Token> sentenceToken = FeatureUtils.getTokenArrayList(JCasUtil.selectCovered(jcas, Token.class, sentence));
			ArrayList<Token> propTokens = FeatureUtils.getTokenArrayList(JCasUtil.selectCovered(jcas, Token.class, classificationUnit));
			
			int startIndex = FeatureUtils.getStartToken(sentenceToken, propTokens);
			for (int i=0; i<startIndex; i++) {
				tokens.add(sentenceToken.get(i));
			}
		}
		
		return tokens;
	}
	

	public static ArgumentComponent getPrecedingArgProp(Annotation classificationUnit) {
		ArgumentComponent prop = null;
		List<ArgumentComponent> preceding = JCasUtil.selectPreceding(ArgumentComponent.class, classificationUnit, 1);
		
		int max = 0;
		for (ArgumentComponent p : preceding) {
			if (p.getEnd()>max) {
				max = p.getEnd();
				prop = p;
			}
		}
		
		return prop;
	}
	
	
	public static Collection<Sentence> getSentenceNext(JCas jcas, Sentence sentence, int n) {
		Collection<Sentence> sentences = JCasUtil.select(jcas, Sentence.class);
		boolean foundSentence = false;		
		Collection<Sentence> nexts =  new ArrayList<Sentence>();;
		int count = 0;
		for (Sentence s : sentences) {
			if (foundSentence) {			
				nexts.add(s); 
				count ++;
				if (count == n){break;}
			}
			if (s.getBegin()==sentence.getBegin() && s.getEnd()==sentence.getEnd()) {
				foundSentence = true;
			}
		}	
		
		return nexts;
	}
	
	
	public static Paragraph getFocusedParagraph(Collection<Paragraph> allParagraphs, Annotation focusedArgProposition){
		Paragraph focusedparagraph =  null;
		for (Paragraph para: allParagraphs){
			if ((focusedArgProposition.getBegin() >=  para.getBegin()) && (focusedArgProposition.getEnd() <=  para.getEnd())){
				focusedparagraph =  para;
			}
		}
		return focusedparagraph;
	} 

	
	public static Collection<Sentence> getSentenceOfCoveringParagraph(JCas jcas, Sentence sentence){
		Collection<Sentence> sentencesCoveredpara =  new ArrayList<Sentence>();
		Paragraph focusedPara= getFocusedParagraph(JCasUtil.select(jcas, Paragraph.class),sentence);
		
		if (focusedPara!=null) {
			sentencesCoveredpara = JCasUtil.selectCovered(Sentence.class, focusedPara);
		}
		
		return sentencesCoveredpara;
		
		
	}
	
}
