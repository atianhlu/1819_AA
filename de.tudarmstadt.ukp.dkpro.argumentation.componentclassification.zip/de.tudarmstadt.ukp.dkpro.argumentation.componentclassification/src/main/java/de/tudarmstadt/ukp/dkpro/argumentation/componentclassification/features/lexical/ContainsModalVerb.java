/*******************************************************************************
 * Copyright 2015
 * Ubiquitous Knowledge Processing (UKP) Lab
 * Technische Universität Darmstadt
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU Public License v3.0
 * which accompanies this distribution, and is available at
 * http://www.gnu.org/licenses/gpl-3.0.txt
 ******************************************************************************/
package de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.lexical;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.uima.fit.util.JCasUtil;
import org.apache.uima.jcas.JCas;

import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token;
import de.tudarmstadt.ukp.dkpro.tc.api.exception.TextClassificationException;
import de.tudarmstadt.ukp.dkpro.tc.api.features.ClassificationUnitFeatureExtractor;
import de.tudarmstadt.ukp.dkpro.tc.api.features.Feature;
import de.tudarmstadt.ukp.dkpro.tc.api.features.FeatureExtractorResource_ImplBase;
import de.tudarmstadt.ukp.dkpro.tc.api.type.TextClassificationUnit;

/**
 * Extracts the number of Claim indicators for a sentence.
 * 
 * @author Christian Stab
 */
public class ContainsModalVerb extends FeatureExtractorResource_ImplBase implements ClassificationUnitFeatureExtractor {

	public static final String FN_CONTAINS_MODAL_VERB = "Contains_Modal_Verb";
	public static final String FN_CONTAINS_MODAL_SHOULD = "Contains_Modal_Should";
	public static final String FN_CONTAINS_MODAL_WOULD = "Contains_Modal_Would";
	public static final String FN_CONTAINS_MODAL_COULD = "Contains_Modal_Could";
	
	
    public List<Feature> extract(JCas jcas, TextClassificationUnit classificationUnit) throws TextClassificationException {
    	List<Feature> featList = new ArrayList<Feature>();
    	boolean modalInSentence = false;
    	boolean modalWould = false;
    	boolean modalCould = false;
    	boolean modalShould = false;
    	
    	Collection<Token> tokens = JCasUtil.selectCovered(jcas, Token.class, classificationUnit);
    	 
    	
    	for (Token t : tokens) {
    		if (t.getPos()!=null && t.getPos().getPosValue()!=null && t.getPos().getPosValue().equals("MD")) {
    			modalInSentence = true;
    			if (t.getCoveredText().toLowerCase().equals("would")) modalWould = true;
    			if (t.getCoveredText().toLowerCase().equals("should")) modalShould = true;
    			if (t.getCoveredText().toLowerCase().equals("could")) modalCould = true;
    		}
    	}

    	featList.add(new Feature(FN_CONTAINS_MODAL_VERB, modalInSentence));
    	featList.add(new Feature(FN_CONTAINS_MODAL_COULD, modalCould));
    	featList.add(new Feature(FN_CONTAINS_MODAL_SHOULD, modalShould));
    	featList.add(new Feature(FN_CONTAINS_MODAL_WOULD, modalWould));
    	return featList;
    }
    
    
}
