/*******************************************************************************
 * Copyright 2015
 * Ubiquitous Knowledge Processing (UKP) Lab
 * Technische Universität Darmstadt
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU Public License v3.0
 * which accompanies this distribution, and is available at
 * http://www.gnu.org/licenses/gpl-3.0.txt
 ******************************************************************************/
package de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.structural;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.uima.fit.util.JCasUtil;
import org.apache.uima.jcas.JCas;

import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.utils.FeatureUtils;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Paragraph;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Sentence;
import de.tudarmstadt.ukp.dkpro.tc.api.exception.TextClassificationException;
import de.tudarmstadt.ukp.dkpro.tc.api.features.ClassificationUnitFeatureExtractor;
import de.tudarmstadt.ukp.dkpro.tc.api.features.Feature;
import de.tudarmstadt.ukp.dkpro.tc.api.features.FeatureExtractorResource_ImplBase;
import de.tudarmstadt.ukp.dkpro.tc.api.type.TextClassificationUnit;

/**
 * @author Christian Stab
 */
public class PositionInParagraph extends FeatureExtractorResource_ImplBase implements ClassificationUnitFeatureExtractor {
	
	public static String FN_POSITION_IN_PARAGRAPH = "Position_In_Paragraph";
	public static String FN_FIRST_SENTENCE_IN_PARAGRAPH = "First_Sentence_In_Paragraph";
	public static String FN_LAST_SENTENCE_IN_PARAGRAPH = "Last_Sentence_In_Paragraph";
	
	public List<Feature> extract(JCas jcas, TextClassificationUnit classificationUnit) throws TextClassificationException {
		List<Feature> featList = new ArrayList<Feature>();
		
		Sentence sentence = FeatureUtils.getCoveringSentence(classificationUnit);
		
		int positionInParagraph = 0;
		boolean firstSentenceInParagraph = false;
		boolean lastSentenceInParagraph = false;
		
		//Collection<Paragraph> paragraphs = JCasUtil.selectCovered(jcas, Paragraph.class, classificationUnit);
		Collection<Paragraph> paragraphs = JCasUtil.selectCovering(Paragraph.class, sentence);
		//if (paragraphs.size()!=1) System.out.println("######################## ERROR: found more than one paragraph");
		if(paragraphs.size() > 1) {
    		throw new TextClassificationException("Multiple Paragraph annotations for "
    				+ "a single TextClassificationUnit. Unable to extract feature: " + FN_POSITION_IN_PARAGRAPH);
    	}
		
		if (paragraphs.size()==1) {
			Paragraph paragraph = paragraphs.iterator().next();
			Collection<Sentence> sentencesInParagraph = JCasUtil.selectCovered(jcas, Sentence.class, paragraph);
			
			int sentenceCounter = 1;
			for (Sentence s : sentencesInParagraph) {
				if (s.getBegin()==sentence.getBegin() && s.getEnd()==sentence.getEnd()) break;
				sentenceCounter++;
			}
			
			if (sentenceCounter>=1) positionInParagraph = sentenceCounter;
			if (sentenceCounter==1) firstSentenceInParagraph = true;
			if (sentenceCounter==sentencesInParagraph.size()) lastSentenceInParagraph = true;
		}
		
		
		featList.add(new Feature(FN_POSITION_IN_PARAGRAPH, positionInParagraph));
		featList.add(new Feature(FN_FIRST_SENTENCE_IN_PARAGRAPH, firstSentenceInParagraph));
		featList.add(new Feature(FN_LAST_SENTENCE_IN_PARAGRAPH, lastSentenceInParagraph));
		return featList;
	}

}
