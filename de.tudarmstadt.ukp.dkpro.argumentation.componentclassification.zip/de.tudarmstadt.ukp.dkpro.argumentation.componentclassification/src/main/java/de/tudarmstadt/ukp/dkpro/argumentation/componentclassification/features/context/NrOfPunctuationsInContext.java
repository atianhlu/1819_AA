/*******************************************************************************
 * Copyright 2015
 * Ubiquitous Knowledge Processing (UKP) Lab
 * Technische Universität Darmstadt
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU Public License v3.0
 * which accompanies this distribution, and is available at
 * http://www.gnu.org/licenses/gpl-3.0.txt
 ******************************************************************************/
package de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.context;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.uima.fit.util.JCasUtil;
import org.apache.uima.jcas.JCas;

import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.utils.ContextUtils;
import de.tudarmstadt.ukp.dkpro.core.api.lexmorph.type.pos.PUNC;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Sentence;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token;
import de.tudarmstadt.ukp.dkpro.tc.api.exception.TextClassificationException;
import de.tudarmstadt.ukp.dkpro.tc.api.features.ClassificationUnitFeatureExtractor;
import de.tudarmstadt.ukp.dkpro.tc.api.features.Feature;
import de.tudarmstadt.ukp.dkpro.tc.api.features.FeatureExtractorResource_ImplBase;
import de.tudarmstadt.ukp.dkpro.tc.api.type.TextClassificationUnit;

/**
 * @author Christian Stab
 */
public class NrOfPunctuationsInContext extends FeatureExtractorResource_ImplBase implements ClassificationUnitFeatureExtractor {

    public static final String FN_NR_OF_PUNCTUATIONS_BEFORE = "NrOfPunctuationsSentenceBefore";
    public static final String FN_NR_OF_PUNCTUATIONS_NEXT = "NrOfPunctuationsSentenceNext";

    public List<Feature> extract(JCas jcas, TextClassificationUnit classificationUnit) throws TextClassificationException {
        List<Feature> featList = new ArrayList<Feature>();

        Sentence sentence = JCasUtil.selectCovering(Sentence.class, classificationUnit).get(0);
        Sentence before = ContextUtils.getSentenceBefore(jcas, sentence, true);
        Sentence next = ContextUtils.getSentenceNext(jcas, sentence, true);
        
        int punctuationsBefore = -1;
        int punctuationsNext = -1;
        
        if (before!=null) {
        	Collection<Token> tokens = JCasUtil.selectCovered(jcas, Token.class, before);
            for (Token t : tokens) {
            	if (t.getPos() instanceof PUNC) punctuationsBefore++;
            }
        }
        
        if (next!=null) {
        	Collection<Token> tokens = JCasUtil.selectCovered(jcas, Token.class, next);
        	for (Token t : tokens) {
            	if (t.getPos() instanceof PUNC) punctuationsNext++;
            }
        }
        
        
        featList.add(new Feature(FN_NR_OF_PUNCTUATIONS_BEFORE, punctuationsBefore));
        featList.add(new Feature(FN_NR_OF_PUNCTUATIONS_NEXT, punctuationsNext));
       
        return featList;
    }

}
