/*******************************************************************************
 * Copyright 2015
 * Ubiquitous Knowledge Processing (UKP) Lab
 * Technische Universität Darmstadt
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU Public License v3.0
 * which accompanies this distribution, and is available at
 * http://www.gnu.org/licenses/gpl-3.0.txt
 ******************************************************************************/
package de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.readers;

import java.io.IOException;
import java.util.Collection;
import java.util.Map;

import org.apache.uima.UimaContext;
import org.apache.uima.cas.CAS;
import org.apache.uima.cas.CASException;
import org.apache.uima.collection.CollectionException;
import org.apache.uima.fit.util.JCasUtil;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceInitializationException;

import de.tudarmstadt.ukp.dkpro.argumentation.types.Claim;
import de.tudarmstadt.ukp.dkpro.argumentation.types.MajorClaim;
import de.tudarmstadt.ukp.dkpro.argumentation.types.Premise;
import de.tudarmstadt.ukp.dkpro.core.api.metadata.type.DocumentMetaData;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Sentence;
import de.tudarmstadt.ukp.dkpro.core.io.xmi.XmiReader;
import de.tudarmstadt.ukp.dkpro.tc.api.type.TextClassificationOutcome;
import de.tudarmstadt.ukp.dkpro.tc.api.type.TextClassificationUnit;

/**
 * 
 * @author Christian Stab
 */
public class ArgumentReader extends XmiReader {

	//private final Log logger = LogFactory.getLog(getClass());
	
	private Map<Sentence, Collection<Premise>> premiseMap;
	private Map<Sentence, Collection<Claim>> claimMap;
	private Map<Sentence, Collection<MajorClaim>> majorClaimMap;
	
	@Override
	public void initialize(UimaContext context) throws ResourceInitializationException {
	    super.initialize(context);
	}
	
	@Override
	public void getNext(CAS aCAS) throws IOException, CollectionException {
	    super.getNext(aCAS);
	
	    JCas jcas;
	    try {
	        jcas = aCAS.getJCas();
	    } catch (CASException e) {
	        throw new CollectionException();
	    }
	    
	    DocumentMetaData.get(jcas).setDocumentTitle(DocumentMetaData.get(jcas).getDocumentId());
	    
	    premiseMap = JCasUtil.indexCovered(jcas, Sentence.class, Premise.class);
		claimMap = JCasUtil.indexCovered(jcas, Sentence.class, Claim.class);
		majorClaimMap = JCasUtil.indexCovered(jcas, Sentence.class, MajorClaim.class);
	    
	    Collection<Sentence> sentences = JCasUtil.select(jcas, Sentence.class);
	    
	    for (Sentence s : sentences) {
	   
	    	if (majorClaimMap.containsKey(s)) {
	    		Collection<MajorClaim> majorClaims = majorClaimMap.get(s);
	    		for (MajorClaim mc : majorClaims) {
	    			new TextClassificationUnit(jcas, mc.getBegin(), mc.getEnd()).addToIndexes();
	    			TextClassificationOutcome outcome = new TextClassificationOutcome(jcas, mc.getBegin(), mc.getEnd());
	    			outcome.setOutcome("MajorClaim");
	    			outcome.addToIndexes();
	    		}
	    	}
	    	if (claimMap.containsKey(s)) {
	    		Collection<Claim> claims = claimMap.get(s);
	    		for (Claim c : claims) {
	    			new TextClassificationUnit(jcas, c.getBegin(), c.getEnd()).addToIndexes();
	    			TextClassificationOutcome outcome = new TextClassificationOutcome(jcas, c.getBegin(), c.getEnd());
	    			outcome.setOutcome("Claim");
	    			outcome.addToIndexes();
	    		}
	    	}
	    	if (premiseMap.containsKey(s)) {
	    		Collection<Premise> premises = premiseMap.get(s);
	    		for (Premise p : premises) {
	    			new TextClassificationUnit(jcas, p.getBegin(), p.getEnd()).addToIndexes();
	    			TextClassificationOutcome outcome = new TextClassificationOutcome(jcas, p.getBegin(), p.getEnd());
	    			outcome.setOutcome("Premise");
	    			outcome.addToIndexes();
	    		}
	    		
	    	}
	    	if (!majorClaimMap.containsKey(s) && !claimMap.containsKey(s) && !premiseMap.containsKey(s)) {
	    		new TextClassificationUnit(jcas, s.getBegin(), s.getEnd()-1).addToIndexes();
    			TextClassificationOutcome outcome = new TextClassificationOutcome(jcas, s.getBegin(), s.getEnd()-1);
    			outcome.setOutcome("None");
	    		outcome.addToIndexes();
	    	}
	    	
	    }
	    
		//logger.info("Reading file " + DocumentMetaData.get(jcas).getDocumentId());
	    
	}

}
