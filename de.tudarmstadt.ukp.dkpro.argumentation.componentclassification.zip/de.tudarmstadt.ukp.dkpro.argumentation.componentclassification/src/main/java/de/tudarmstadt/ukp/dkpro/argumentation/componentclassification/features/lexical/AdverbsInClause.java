/*******************************************************************************
 * Copyright 2015
 * Ubiquitous Knowledge Processing (UKP) Lab
 * Technische Universität Darmstadt
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU Public License v3.0
 * which accompanies this distribution, and is available at
 * http://www.gnu.org/licenses/gpl-3.0.txt
 ******************************************************************************/
package de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.lexical;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.apache.uima.fit.descriptor.ConfigurationParameter;
import org.apache.uima.fit.util.JCasUtil;
import org.apache.uima.jcas.JCas;
import org.apache.uima.resource.ResourceInitializationException;
import org.apache.uima.resource.ResourceSpecifier;

import de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.utils.AdverbMetaCollector;
import de.tudarmstadt.ukp.dkpro.core.api.frequency.util.FrequencyDistribution;
import de.tudarmstadt.ukp.dkpro.core.api.lexmorph.type.pos.ADV;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Token;
import de.tudarmstadt.ukp.dkpro.tc.api.exception.TextClassificationException;
import de.tudarmstadt.ukp.dkpro.tc.api.features.ClassificationUnitFeatureExtractor;
import de.tudarmstadt.ukp.dkpro.tc.api.features.Feature;
import de.tudarmstadt.ukp.dkpro.tc.api.features.FeatureExtractorResource_ImplBase;
import de.tudarmstadt.ukp.dkpro.tc.api.features.meta.MetaCollector;
import de.tudarmstadt.ukp.dkpro.tc.api.features.meta.MetaDependent;
import de.tudarmstadt.ukp.dkpro.tc.api.type.TextClassificationUnit;

/**
 * @author Christian Stab
 */
public class AdverbsInClause extends FeatureExtractorResource_ImplBase implements MetaDependent, ClassificationUnitFeatureExtractor{

	
	public static final String FN_ADVERB_FEATURE_PREFIX = "Adverb_";
	
	
	public static final String PARAM_ADVERB_FD_FILE = "adverbFdFile";
    @ConfigurationParameter(name = PARAM_ADVERB_FD_FILE, mandatory = true)
    private String adverbFdFile;
    
    
    public static final String PARAM_NUMBER_OF_ADVERBS = "numberOfAdverbs";
    @ConfigurationParameter(name = PARAM_NUMBER_OF_ADVERBS, mandatory = true, defaultValue="-1")
    private int numberOfAdverbs;
    
    
    public static final String PARAM_THRESHOLD = "threshold";
    @ConfigurationParameter(name = PARAM_THRESHOLD, mandatory = true, defaultValue="10")
    private int threshold;
	
    
    public FrequencyDistribution<String> topKAdverbs;
    
    
    @Override
    public boolean initialize(ResourceSpecifier aSpecifier, Map<String, Object> aAdditionalParams) throws ResourceInitializationException {
    	if (!super.initialize(aSpecifier, aAdditionalParams)) {
            return false;
        }
    	
    	FrequencyDistribution<String> trainingFD;
    	try {
            trainingFD = new FrequencyDistribution<String>();
            trainingFD.load(new File(adverbFdFile));
        } catch (Exception e) {
            throw new ResourceInitializationException(e);
        }
        
    	topKAdverbs = new FrequencyDistribution<String>();
    	
    	if (numberOfAdverbs==-1) {
    		// consider samples up to a given frequency threshold
    		for (String sample : trainingFD.getKeys()) {
    			if (trainingFD.getCount(sample)>=threshold) {
    				topKAdverbs.addSample(sample, trainingFD.getCount(sample));
    			}
    		}
    	} else {
    		// consider a given number of verbs
	    	List<String> topK = trainingFD.getMostFrequentSamples(numberOfAdverbs);
	    	for (String sample : topK) {
	    		topKAdverbs.addSample(sample, trainingFD.getCount(sample));
	    	}
    	}
    	
    	getLogger().info("Loaded " + topKAdverbs.getKeys().size() + " adverbs for feature extraction");
    	
    	return true;
    }
    
    
    public List<Class<? extends MetaCollector>> getMetaCollectorClasses() {
        List<Class<? extends MetaCollector>> metaCollectorClasses = new ArrayList<Class<? extends MetaCollector>>();
        metaCollectorClasses.add(AdverbMetaCollector.class);
        
        return metaCollectorClasses;
    }
	
	
    public List<Feature> extract(JCas jcas, TextClassificationUnit classificationUnit) throws TextClassificationException {
        List<Feature> featList = new ArrayList<Feature>();
        
        // extract features
        for (String adverb : topKAdverbs.getKeys()) {
        	boolean foundAdverb = false;
        	
        	Collection<Token> tokens = JCasUtil.selectCovered(Token.class, classificationUnit);
        	for (Token t : tokens) {
        		if (t.getPos()!=null && t.getPos() instanceof ADV && t.getLemma().getValue().equals(adverb)) foundAdverb=true;
        	}
        	if (foundAdverb) featList.add(new Feature(FN_ADVERB_FEATURE_PREFIX + adverb, true));
        	else featList.add(new Feature(FN_ADVERB_FEATURE_PREFIX + adverb, false));
        }
        
        return featList;
	}
}
