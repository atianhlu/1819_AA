/*******************************************************************************
 * Copyright 2015
 * Ubiquitous Knowledge Processing (UKP) Lab
 * Technische Universität Darmstadt
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU Public License v3.0
 * which accompanies this distribution, and is available at
 * http://www.gnu.org/licenses/gpl-3.0.txt
 ******************************************************************************/
package de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.features.utils;

import java.util.Collection;

import org.apache.uima.fit.util.JCasUtil;
import org.apache.uima.jcas.JCas;

import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Paragraph;
import de.tudarmstadt.ukp.dkpro.core.api.segmentation.type.Sentence;

/**
 * @author Christian Stab
 */
public class ContextUtils {

	
	public static Sentence getSentenceBefore(JCas jcas, Sentence sentence, boolean considerParagraphBoundaries) {
		Collection<Sentence> sentences = JCasUtil.select(jcas, Sentence.class);
		Sentence before = null;
		for (Sentence s : sentences) {
			if (s.getBegin()==sentence.getBegin() && s.getEnd()==sentence.getEnd()) break;
			before = s;
		}
		
		if (considerParagraphBoundaries) {
			return (isInSameParagraph(jcas, sentence, before))?before:null;
		} else {
			return before;
		}
	}
	
	
	public static Sentence getSentenceNext(JCas jcas, Sentence sentence, boolean considerParagraphBoundaries) {
		Collection<Sentence> sentences = JCasUtil.select(jcas, Sentence.class);
		boolean foundSentence = false;
		Sentence next = null;
		for (Sentence s : sentences) {
			if (foundSentence) {
				next = s;
				break;
			}
			if (s.getBegin()==sentence.getBegin() && s.getEnd()==sentence.getEnd()) {
				foundSentence = true;
			}
		}
		if (considerParagraphBoundaries) {
			return (isInSameParagraph(jcas, sentence, next))?next:null;
		} else {
			return next;
		}
	}

	
	public static boolean isInSameParagraph(JCas jcas, Sentence s1, Sentence s2) {
		return s1!=null && s2!=null && getCoveringParpagraph(s1)==getCoveringParpagraph(s2);
	}
	
	
	public static Paragraph getCoveringParpagraph(Sentence sentence) {
		Collection<Paragraph> paragraphs = JCasUtil.selectCovering(Paragraph.class, sentence);
		if(paragraphs.size() != 1) {
    		return null;
    	} else {
    		return paragraphs.iterator().next();
    	}
	}
	
}
