This project includes the experiment for argument component classification in 
persuasive essaysintroduced in the following paper:

 	Christian Stab and Iryna Gurevych. 2014: Identifying Argumentative Discourse 
 	Structures in Persuasive Essays. In Proceedings of Conference on Empirical 
 	Methods in Natural Language Processing (EMNLP 2014), pages 46-56, Doha, Qatar 

Note: The project also contains the preprocessed train-test-split of the data
presented in the following work:

	Christian Stab and Iryna Gurevych.2014. Annotating Argument Components and 
	Relations in Persuasive Essays. In Proceedings of the the 25th International 
	Conference on Computational Linguistics (COLING 2014), p.1501-1510, Dublin, Ireland 


INSTALL & SETUP

1. Import the project in Eclipse by using "File -> Import -> Existing Maven Projects"

2. Configuring Maven for full access to the UKP Maven Repository by downloading the
   settings.xml file from https://code.google.com/p/dkpro-core-asl/wiki/UkpMavenRepository
   
3. Copy the settings.xml file into your ".m2" directory.

4. Enable option for downloading snapshot versions by uncommenting ukp-oss-snapshots 
   profile in the settings.xml
   
5. Right click on the project in your Package Explorer and select "Maven -> Update Project..."
   Enable "Force update of Snapshots/Releases"


RUN THE EXPERIMENT

Run de.tudarmstadt.ukp.dkpro.argumentation.componentclassification.experiments.ComponentClassification

The results will be stored in src/main/resources/results


